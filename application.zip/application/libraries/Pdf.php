<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// require_once(dirname(__FILE__) . '/dompdf/autoload.inc.php');
require 'vendor/autoload.php';
use Dompdf\Dompdf;
class Pdf extends DOMPDF
{
    function __construct()
    {
        parent::__construct();
    }
}
?>