<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php $user = $this->session->userdata('user_id'); 
    if(!is_numeric($user)){
        redirect('users/login');
    }    
?>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css"
        integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

<style>

/* @import url('https://fonts.googleapis.com/css?family=Roboto&display=swap');
@import url('https://fonts.googleapis.com/css?family=Montserrat&display=swap');
@import url('https://fonts.googleapis.com/css?family=Audiowide&display=swap');
@import url('https://fonts.googleapis.com/css?family=Anton|Orbitron|Play|Squada+One|Ubuntu&display=swap');
@import url('https://fonts.googleapis.com/css?family=Open+Sans&display=swap'); */

/* @page { margin: 0px; } */
 
        
body {
    -webkit-font-smoothing: antialiased;
    -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
    /* font-family: 'Montserrat', sans-serif; */
    /* font-weight: bolder; */
    font-size: 13px;
    box-sizing: border-box;
    margin: 0;

    
    width: 100%;
}
div{
    padding: 0;
    margin: 0;
}
div.forbuyer{
    background: url("<?php echo base_url()."/assets/img/prologobek.png"; ?>") cover no-repeat;
}
.info-company{
    margin-top: 5px;
    margin-left: 30px;
    display: inline-block;
}
.info-company>div{
    line-height: 1;
}
.info-byer{
    margin-left: 70px;
    display: inline-block;
}

table.table.table-borderless td {
    padding: 5px;
    min-width: 2%;
}

.seller img{
    max-width: 120px;
    /* margin-top: 10px; */
    vertical-align: top;
}

.seller{
    color: #0288d1;
    border-bottom: 1px solid black;
}
.buyer{
    padding-left: 20px;
    display: inline-block;
}
.invoice{
    
    margin-left: 300px;
    margin-top: 23px;
    display: inline-block;
}
.forbuyer{
    display: inline-flex!important;
    border-bottom: 1px solid black;
}
.forbuyer>*{
z-index: 5
}
.my-table > img{
    width:100%;
    height: 202px;
    z-index: 2!important;
    opacity: .12;
    position: fixed;
    top: 73px;
    left: 0px;
}
.ccc{
    margin-top: 80px;
}

.tabela{
    font-size: 11px;
    border-top:1px solid black;
}
thead{
    background: #d2e9fa;
    border-bottom: 1px dotted black;
}

.hhh{
    margin-top: 10px;
    font-style: italic;
    margin-bottom: 10px;
    font-weight: bold;
}
.nnn{
    
    border-top: 1px solid black;
    font-weight: bold;
}
.notes{
    width: -webkit-fill-available;
    display: inline-block;
    margin-top: 50px;
}
.signature{
    width: 150px;
    display: inline-block;
    border-bottom: 1px solid black;
    padding: 30px;
    margin-left: 97px;
}
/* .signature2{
    margin-left: 110px;
    display: inline-block;
} */

.bigsign{
    margin-top: 40px;
}
</style>

    <div class="my-table">
        <div class="seller">
            <img src="<?php echo base_url().'/assets/img/prologo.png'; ?>" alt="">
            <div class="info-company">
                <div ><?php echo $invoice['sellername']; ?></div>
                <div ><?php echo $invoice['selleradress']; ?></div>
                <div ><?php echo $invoice['sellerzip']; ?> <?php echo $invoice['sellercity']; ?></div>
                <div ><b>Pib: </b><?php echo $invoice['sellerpib']; ?> <b>MB: </b> <?php echo $invoice['sellermb']; ?></div>
            </div>
            <div class="info-company">
                <div >Banka: <?php echo $invoice['sellerbank']; ?></div>
                <div >Račun: <?php echo $invoice['selleracc_num']; ?></div>
                <div ><?php echo $invoice['sellerphone']; ?></div>
                <div ><?php echo $invoice['selleremail']; ?></div>
            </div>
        </div>
        <img src="<?php echo base_url().'/assets/img/prologobek.png'; ?>" alt="">
        <div class="forbuyer">
            <div class="buyer">
                <b>Faktura za: </b><div><?php echo $invoice['buyername']; ?></div>
                <!-- <div class="info-byer"> -->
                <div><?php echo $invoice['buyeradress']; ?></div>
                <div><?php echo $invoice['buyerzip']; ?> <?php echo $invoice['buyercity']; ?></div>
                <div><b>Pib: </b><?php echo $invoice['buyerpib']; ?></div>
                <div><b>MB: </b><?php echo $invoice['buyermb']; ?></div>
                <!-- </div> -->
            </div>
            <div class="invoice">
                <div class="text-uppercase"><?php echo $type; ?></div>
                <div>Br fakture: <?php echo $invoice['inv_num']; ?></div>
                <div>Datum: <?php echo $invoice['date']; ?></div>
                <div>Ukupno za uplatu: <?php echo $invoice['total']; ?></div>
                <div>Plaćeno: <?php echo $invoice['payed']; ?></div>
                <div>Duguje: <?php echo $invoice['due']; ?></div>
                <div>Rok plaćanja: <?php echo $invoice['pay_deadline']; ?></div>
            </div>
        </div>
        <!-- <div class="black-line"></div> -->
        <div class="tabela">
               <div class="hhh">Artikli i usluge</div>
            <table class="table table-borderless" id="mydata">
                <thead>
                    <tr>
                        <td style="width:2%">rb</td>
                        <td style="width:22%">Naziv</td>
                        <td>Cena</td>
                        <td >Količina</td>
                        <td >Jedinica mere</td>
                        <td >Popust(%)</td>
                        <td>Ukupna cena</td>
                        <td >Poreska osnovica</td>
                        <td>Iznos PDV-a</td>
                        <td>Ukupan iznos</td>
                    </tr>
                </thead>

                <tbody>
                    <?php $rb = 1; foreach($invoice_items as $key => $value): ;?>
                    <tr>
                        <td style="width:2%"> <?php echo $rb;?></td>
                        <td><?php echo $value['name'] ;?></td>
                        <td><?php echo $value['price'] ;?></td>
                        <td><?php echo $value['quantity'] ;?></td>
                        <td><?php echo $value['mes_unit'] ;?></td>
                        <td><?php echo $value['it_disc'] ;?></td>
                            <?php 
                            $widhout_tax = $value['quantity']*$value['price'] - ($value['quantity']*$value['price']*($value['it_disc']/100));
                            $tax_total  = $widhout_tax*($value['tax']/100); 
                            ?>
                        <td><?php echo $widhout_tax ;?></td>
                        <td><?php echo$value['tax'] ;?></td>
                        <td><?php echo $tax_total ;?></td>
                        <td><?php echo $value['total'] ;?></td>
                    </tr>
                    <?php $rb++; endforeach; ?>
                    <?php echo $html_total; ?>
                </tbody>
            </table>
            <div>
                Iznos za uplatu slovima: <?php echo $invoice['letters'] ;?>
            </div>
        </div>
        <div class="notes">
            <b>Napomena: </b><?php echo $invoice['notes'] ;?>
        </div>
        <div class="bigsign">
            <div class="signature">
                Za prodavca
            </div>
            <div class="signature signature2">
                Za kupca
            </div>
        </div>
    </div><!-- faktura -->
