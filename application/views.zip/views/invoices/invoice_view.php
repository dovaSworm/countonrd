<?php $user = $this->session->userdata('user_id');
if (!is_numeric($user)) {
    redirect(base_url() . 'users/login');
}
?>

<!-- <img src="https://github.com/dovaSworm/front-end/blob/master/Pipboy/img/angry.jpg?raw=true" alt=""> -->
<div class="container-fluid">
<div class="mytitle">
    <h6 class="text-center my-1">CountOn<img src="<?php echo base_url() . '/assets/img/sivibek.svg'; ?>" alt=""></h6>
</div>
    <div class="my-table">
        <div class="row no-gutters">
            <div class="col-sm-12 col-md-4 bg-light p-4">

               <h5>Prodavac</h5>
               <div><?php echo $invoice['sellername']; ?></div>
               <div><?php echo $invoice['selleradress']; ?></div>
               <div><?php echo $invoice['sellerzip']; ?></div>
               <div><?php echo $invoice['sellercity']; ?></div>
               <div><?php echo $invoice['sellermb']; ?></div>
               <div><?php echo $invoice['sellerpib']; ?></div>
            </div>
            <div class="col-sm-12 col-md-4 bg-light p-4">
            <h5>Kupac</h5>
               <div><?php echo $invoice['buyername']; ?></div>
               <div><?php echo $invoice['buyeradress']; ?></div>
               <div><?php echo $invoice['buyerzip']; ?></div>
               <div><?php echo $invoice['buyercity']; ?></div>
               <div><?php echo $invoice['buyermb']; ?></div>
               <div><?php echo $invoice['buyerpib']; ?></div>
            </div>

            <div class="col-sm-12 col-md-4 p-2">
                <?php echo form_open('invoices/update/' . $invoice['id']); ?>
                <div><label>Vrsta dokumenta:</label>
                <?php if ($invoice['avans'] == 1): ?>
                <span class="text-uppercase">Avansni račun</span>
                <?php elseif ($invoice['profaktura'] == 1): ?>
                <span class="text-uppercase">Profaktura</span>
                <?php else: ?>
                <span class="text-uppercase">Faktura</span>
                <?php endif;?>
               </div>
               <div><label>Datum:</label><span><input type="text" size="10" name="date" id="date"
                                    value="<?php echo $invoice['date']; ?>"></span></div>
               <div><label>Broj fakture:</label><span><span><?php echo $invoice['inv_num']; ?></span></div>
               <div><label>Popust:</label><span><input type="text" name="discount" id="discount" size="10"
                                    value="<?php echo $invoice['discount']; ?>"></span></div>
                <div><label class="text-uppercase">Za uplatu: </label><span><?php echo $invoice['total']; ?></span></div>
                <div><label class="text-uppercase">Plaćeno:</label><span><?php echo $invoice['payed']; ?></span></div>
                <div><label>Plati sad:</label><span><input type="text" name="payed" size="10" value=""></span></div>
                <div><label class="text-uppercase">Duguje:</label><span><?php echo $invoice['due']; ?></span></div>
                <div><label>Rok plaćanja:</label><span><input type="text" size="10" name="pay-deadline" id="pay-deadline" 
                                    value="<?php echo $invoice['pay_deadline']; ?>"></span></div>
                <div><label>Slovima:</label><span><input class="w-70" type="text"  name="letters" 
                                    value="<?php echo $invoice['letters']; ?>"></span></div>
                <div class="text-center"><button id="edit-invoice"
                                    class="btn-sec text-uppercase" type="submit">Snimi izmene</button></div>
                <?php echo form_close(); ?>
            </div>
        </div>
        <!--row -->

        <?php if ($invoice['avans'] == 0): ?>
        <div class="col-sm-12 my-2 py-1 bg-light">
            <?php echo form_open('invoice_items/create/' . $invoice['id']); ?>
            <div class="form-inline p-2">
                <label>Dodaj artikal na fakturu</label>
                <?php if (form_error('item')) {
    echo '<div class="alert alert-warning">' . form_error('item') . '</div>';
}?>
                <div class="row no-gutters d-inline-flex">
                    <select name="item" id="item">
                        <?php foreach ($items as $key => $value): ?>
                        <option value="<?php echo $item = $value['id']; ?>"><?php echo $value['name']; ?></option>
                        <?php endforeach;?>
                    </select>
                    <button title="Add article" id="add-item-btn" class="ml-2 btn-default text-primary text-uppercase"
                        type="submit"><i class="fas fa-plus"></i></button>
                </div>
            </div>
            <?php echo form_close(); ?>
        </div>

        <div class="col-sm-12 table-responsive table-striped table-borderless w-auto my-3">
            <table class="table" id="mydata">
                <thead>
                    <tr>
                        <th>rb</th>
                        <th>Naziv</th>
                        <th>Cena</th>
                        <th>Količina</th>
                        <th>Jedinica mere</th>
                        <th>Popust(%)</th>
                        <th>Ukupna cena</th>
                        <th>Poreska osnovica</th>
                        <th>Iznos PDV-a</th>
                        <th>Ukupan iznos</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $rb = 1;foreach ($invoice_items as $key => $value): ;?>
		                    <?php echo form_open('invoice_items/update/' . $value['id']); ?>
		                    <tr>
		                        <td> <?php echo $rb; ?></td>
		                        <td><?php echo $value['name']; ?></td>
		                        <td><input type="text" name="price" class="price" size="7"
		                                value="<?php echo $value['price']; ?>"></td>
		                        <td><input type="text" name="quantity" class="quantity" size="3"
		                                value="<?php echo $value['quantity']; ?>"></td>
		                        <td><?php echo $value['mes_unit']; ?></td>
		                        <td><input type="text" name="it-disc" class="it_disc" size="7"
		                                value="<?php echo $value['it_disc']; ?>"></td>
		                                <?php
    $widhout_tax = $value['quantity'] * $value['price'] - ($value['quantity'] * $value['price'] * ($value['it_disc'] / 100));
    $tax_total = $widhout_tax * ($value['tax'] / 100);
    $with_tax = ($value['price'] + ($value['price'] * ($value['tax'] / 100))) * $value['quantity'];
    ?>
		                        <td><?php echo $widhout_tax; ?></td>
		                        <td><input type="text" name="tax" class="tax" size="3" value="<?php echo $value['tax']; ?>"></td>
		                        <td><?php echo $tax_total; ?></td>
		                        <td><?php echo $value['total']; ?></td>
		                        <td><button title="Izmeni" class="edit-item" type="submit"><i
		                                    class="fas fa-pen"></i></button><?php echo form_close(); ?><input type="hidden"
		                                class="form-control" value="'<?php echo $value['id']; ?>'"></td>
		                        <?php echo form_open('invoice_items/delete/' . $value['id'] . '/' . $invoice['id']); ?><td>
		                            <button title="Obriši" class="delete-item" type="submit"><i
		                                    class="fas fa-trash-alt"></i></button></td><?php echo form_close(); ?>
		                    </tr>

		                    <?php $rb++;endforeach;?>

                    <tr class="font-weight-bold"><strong><?php echo $html_total; ?></strong></tr>


                </tbody>
            </table>
        </div>
        <?php endif;?>
        <div class="bg-light p-2 my-3"><strong>Napomena:</strong> <?php echo $invoice['notes']; ?></div>
        <div class="text-center">
            <button class="my-3 btn-sec text-uppercase"><a href="<?php echo base_url() . 'invoices/make_pdf/' . $invoice['id']; ?>">Napravi pdf fakturu</a></button>
        </div>
    </div><!-- faktura -->
</div><!-- container -->
<?php if ($this->session->flashdata('invoiceitem_created')): ?>
<?php echo '<p class="alert alert-success">' . $this->session->flashdata('invoiceitem_created') . '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>'; ?>
<?php endif;?>
